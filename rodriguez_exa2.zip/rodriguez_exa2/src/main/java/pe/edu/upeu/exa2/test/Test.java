package pe.edu.upeu.exa2.test;

import com.google.gson.Gson;

import pe.edu.upeu.exa2.config.Conexion;

public class Test {
	static Gson gson = new Gson();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if (Conexion.getConexion() != null) {
			System.out.println("Conectado");

		} else {
			System.out.println("No se pudo conectar");
		}
	}
}
