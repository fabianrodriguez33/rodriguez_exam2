package pe.edu.upeu.exa2.dao;

import pe.edu.upeu.exa2.entity.Facultad;
import pe.edu.upeu.exa2.general.Generic;

public interface FacultadDao extends Generic<Facultad>{

}
